<h1>Sistem Pakar Pendeteksi Penyakit Menggunakan Metode Forward Chaining</h1>
<h5>Pemrograman Berbasis Objek - TI.3B</h5>
<h5>Nama Anggota Kelompok : </h5>
<ul>
  <li>Aji Santoso [17200019]</li>
  <li>Ramdan Umbara [17200031]</li>
  <li>An-nisa Nur Fathihah [17200018]</li>
</ul>
<p>Sistem Pakar adalah sistem informasi yang berisi pengetahuan seorang pakar sehingga dapat digunakan untuk konsultasi, sistem pakar ini berbasis desktop. Metode Forward Chaining adalah metode pencarian / penarikan kesimpulan yang berdasarkan pada data atau fakta yang ada menuju ke kesimpulan. Dalam sistem pakar ini dapat mendeteksi beberapa penyakit umum.</p>
<h5>Fitur - fitur admin : </h5>
<ul>
  <li>Signin</li>
  <li>Signup</li>
  <li>CRUD Akun</li>
  <li>CRUD Data Penyakit</li>
  <li>CRUD Data Gejala</li>
  <li>CRUD Basis Pengetahuan</li>
  <li>CRUD Aturan</li>
  <li>Diagnosa</li>
</ul>
<h5>Fitur - fitur user : </h5>
<ul>
  <li>Signin</li>
  <li>Signup</li>
  <li>Update Akun</li>
  <li>Diagnosa</li>
</ul>
